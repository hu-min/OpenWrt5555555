#!/bin/sh

PROG_PATH=$(pwd)
$PROG_PATH/adbybyupdate.sh
