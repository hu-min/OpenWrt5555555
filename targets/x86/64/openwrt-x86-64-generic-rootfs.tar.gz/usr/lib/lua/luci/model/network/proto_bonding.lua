local e=luci.model.network:register_protocol("bonding")
function e.get_i18n(e)
return luci.i18n.translate("Link Aggregation (Channel Bonding)")
end
function e.is_installed(e)
return nixio.fs.access("/lib/netifd/proto/bonding.sh")
end
function e.is_virtual(e)
return true
end
function e.is_floating(e)
return true
end
function e.opkg_package(e)
return"bonding"
end
