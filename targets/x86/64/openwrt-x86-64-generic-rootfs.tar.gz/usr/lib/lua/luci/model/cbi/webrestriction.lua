local o=require"luci.sys"
local a,t,e
a=Map("webrestriction",translate("访问限制"),translate(
"使用黑名单或者白名单模式控制列表中的客户端是否能够连接到互联网。"))
a.template="webrestriction/index"
t=a:section(TypedSection,"basic",translate("Running Status"))
t.anonymous=true
e=t:option(DummyValue,"webrestriction_status",translate("当前状态"))
e.template="webrestriction/webrestriction"
e.value=translate("Collecting data...")
t=a:section(TypedSection,"basic",translate("全局设置"))
t.anonymous=true
e=t:option(Flag,"enable",translate("开启"))
e.rmempty=false
e=t:option(ListValue,"limit_type",translate("限制模式"))
e.default="blacklist"
e:value("whitelist",translate("白名单"))
e:value("blacklist",translate("Blacklist"))
e.rmempty=false
t=a:section(TypedSection,"macbind",translate("名单设置"),translate(
"如果是黑名单模式，列表中的客户端将被禁止连接到互联网；白名单模式表示仅有列表中的客户端可以连接到互联网。"))
t.template="cbi/tblsection"
t.anonymous=true
t.addremove=true
e=t:option(Flag,"enable",translate("开启控制"))
e.rmempty=false
e=t:option(Value,"macaddr",translate("MAC地址"))
e.rmempty=true
o.net.mac_hints(function(t,a)e:value(t,"%s (%s)"%{t,a})end)
return a
